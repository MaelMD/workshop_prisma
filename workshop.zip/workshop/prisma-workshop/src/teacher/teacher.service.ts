import { Injectable } from '@nestjs/common';
import { CreateTeacherDto } from './dto/create-teacher.dto';
import { UpdateTeacherDto } from './dto/update-teacher.dto';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class TeacherService {
  create(createTeacherDto: CreateTeacherDto) {
    return 'This action adds a new teacher';
  }

  constructor(private prisma: PrismaService) {}

  findAll(name?: string, age?: number, address?: string, numberOfClasses?: number) {
    const where = {};
  
    if (name !== undefined) {
      where['name'] = name;
    }
    if (age !== undefined) {
      where['age'] = age;
    }
    if (address !== undefined) {
      where['address'] = {
        contains: address,
      }
    }
    if (numberOfClasses !== undefined) {
      where['numberOfClasses'] = numberOfClasses;
    };
  
    return this.prisma.teacher.findMany({
      where,
    });
  }

  findOne(id: number) {
    return this.prisma.teacher.findUnique({
      where : {
        id: id,
      }
    });
  }

  update(id: number, updateTeacherDto: UpdateTeacherDto) {
    return `This action updates a #${id} teacher`;
  }

  remove(id: number) {
    return `This action removes a #${id} teacher`;
  }
}
