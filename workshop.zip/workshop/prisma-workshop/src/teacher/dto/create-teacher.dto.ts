export class CreateTeacherDto {
    name: string
    age: number
    phoneNumber: string
    address: string
    numberOfClasses: number
}
