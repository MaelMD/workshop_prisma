import { Injectable } from '@nestjs/common';
import { CreateStudentDto } from './dto/create-student.dto';
import { UpdateStudentDto } from './dto/update-student.dto';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class StudentService {
  create(createStudentDto: CreateStudentDto) {
    return 'This action adds a new student';
  }

  constructor(private prisma: PrismaService) {}

  findAll(age?: number, price?: number, address?: string) {
    const where = {};
  
    if (age !== undefined) {
      where['age'] = age;
    }
    if (price !== undefined) {
      where['price'] = price;
    }
    if (address !== undefined) {
      where['address'] = {
        contains: address,
      };
    }
  
    return this.prisma.student.findMany({
      where,
    });
  }

  findOne(id: number) {
    return this.prisma.student.findUnique({
      where : {
        id: id,
      }
    });;
  }

  update(id: number, updateStudentDto: UpdateStudentDto) {
    return `This action updates a #${id} student`;
  }

  remove(id: number) {
    return `This action removes a #${id} student`;
  }
}
