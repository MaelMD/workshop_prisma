export class CreateStudentDto {
  name: string
  age: number
  address: string
  parentsPhoneNumber: string
}
